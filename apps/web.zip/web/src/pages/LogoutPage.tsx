const LogoutPage = () => {
  return <div>LogoutPage</div>;
};

export default LogoutPage;
